package LibraryManagementSystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

import BackImage.FullScreenBackground;

public class AddRecord extends JFrame {

    public AddRecord() {
        // Create a FullScreenBackground panel with the desired image
        FullScreenBackground backgroundPanel = new FullScreenBackground("C:\\Users\\Niranjan Mali\\IdeaProjects\\Library\\Images\\");

        // Set layout for the backgroundPanel
        backgroundPanel.setLayout(null);

        JLabel j, j1, j2, j3, j4, j5, j6, j7, j8, j9;
        JTextField t1, t2, t3, t4, t5, t6, t7;
        JButton b1, b2, b3;
        JRadioButton r1, r2, r3;
        JList l1;

        j = new JLabel("Issue Book Record ");
        j1 = new JLabel("Record No :");
        j2 = new JLabel("Enrollment No :");
        j3 = new JLabel("Student Name ");
        j4 = new JLabel("Year : ");
        j5 = new JLabel("Tarde : ");
        j6 = new JLabel("Mobile No :");
        j7 = new JLabel("Book ID :");
        j8 = new JLabel("Book Name :");
        j9 = new JLabel("Author Name");

        t1 = new JTextField();
        t1.setEditable(true);
        t2 = new JTextField();
        t3 = new JTextField();
        t4 = new JTextField();
        r1 = new JRadioButton("FY");
        r2 = new JRadioButton("SY");
        r3 = new JRadioButton("TY");
        ButtonGroup bg = new ButtonGroup();
        bg.add(r1);
        bg.add(r2);
        bg.add(r3);
        r1.setActionCommand("FY");
        r2.setActionCommand("SY");
        r3.setActionCommand("TY");

        String Trades[] = {"Civil", "Mechanical", "Electrical", "Electronics", "Computer", "Instrumentation"};
        l1 = new JList(Trades);
        l1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        t5 = new JTextField();
        t6 = new JTextField();
        t7 = new JTextField();

        b1 = new JButton("Issue Record");
        b2 = new JButton("Search Book");
        b3 = new JButton("Back");

        j.setBounds(700, 200, 400, 40);
        j1.setBounds(120, 250, 150, 30);
        j2.setBounds(120, 300, 180, 30);
        j3.setBounds(120, 350, 150, 30);
        j4.setBounds(120, 400, 150, 30);
        j5.setBounds(120, 450, 150, 30);
        j6.setBounds(1050, 250, 150, 30);
        j7.setBounds(1050, 300, 150, 30);
        j8.setBounds(1050, 400, 150, 30);
        j9.setBounds(1050, 450, 150, 30);

        t1.setBounds(350, 250, 250, 30);
        t2.setBounds(350, 300, 250, 30);
        t3.setBounds(350, 350, 250, 30);
        r1.setBounds(350, 400, 60, 30);
        r2.setBounds(450, 400, 60, 30);
        r3.setBounds(550, 400, 60, 30);
        l1.setBounds(350, 450, 250, 200);

        t4.setBounds(1250, 250, 250, 30);
        t5.setBounds(1250, 300, 250, 30);
        t6.setBounds(1250, 400, 250, 30);
        t7.setBounds(1250, 450, 250, 30);

        b1.setBounds(850, 700, 180, 30);
        b2.setBounds(1050, 350, 180, 30);
        b3.setBounds(750, 100, 180, 30);

        backgroundPanel.add(j);
        backgroundPanel.add(j1);
        backgroundPanel.add(j2);
        backgroundPanel.add(j3);
        backgroundPanel.add(j4);
        backgroundPanel.add(j5);
        backgroundPanel.add(j6);
        backgroundPanel.add(j7);
        backgroundPanel.add(j8);
        backgroundPanel.add(j9);
        backgroundPanel.add(t1);
        backgroundPanel.add(t2);
        backgroundPanel.add(t3);
        backgroundPanel.add(t4);
        backgroundPanel.add(t5);
        backgroundPanel.add(t6);
        backgroundPanel.add(t7);
        backgroundPanel.add(r1);
        backgroundPanel.add(r2);
        backgroundPanel.add(r3);
        backgroundPanel.add(l1);
        backgroundPanel.add(b1);
        backgroundPanel.add(b2);
        backgroundPanel.add(b3);

        setTitle("Issue Record");
        setSize(1100, 900);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(backgroundPanel);
        setVisible(true);
        setExtendedState(JFrame.MAXIMIZED_BOTH);

        // Font settings
        Font myfont = new Font("serif", Font.BOLD, 24);
        j1.setFont(myfont);
        j2.setFont(myfont);
        j3.setFont(myfont);
        j4.setFont(myfont);
        j5.setFont(myfont);
        j6.setFont(myfont);
        j7.setFont(myfont);
        j8.setFont(myfont);
        j9.setFont(myfont);
        b1.setFont(myfont);
        b2.setFont(myfont);
        b3.setFont(myfont);
        t1.setFont(myfont);
        t2.setFont(myfont);
        t3.setFont(myfont);
        t4.setFont(myfont);
        t5.setFont(myfont);
        t6.setFont(myfont);
        t7.setFont(myfont);
        r1.setFont(myfont);
        r2.setFont(myfont);
        r3.setFont(myfont);
        l1.setFont(myfont);

        Font Title = new Font("serif", Font.BOLD, 40);
        j.setForeground(Color.RED);
        j.setFont(Title);

        // Add Record
        b1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/library", "root", "12345678");

                    Statement stmt = conn.createStatement();
                    String sqlInsert = "insert into records values (" + t1.getText() + "," + t2.getText() + ",'" + t3.getText() + "','" + bg.getSelection().getActionCommand() + "','" + l1.getSelectedValue() + "'," + t4.getText() + "," + t5.getText() + ",'" + t6.getText() + "','" + t7.getText() + "')";
                    stmt.executeUpdate(sqlInsert);
                    JOptionPane.showMessageDialog(AddRecord.this, "" + t6.getText() + " is issued to " + t3.getText() + "");

                    // Book count - 1
                    String strSelect1 = "select *  from Books where BookID=" + t5.getText();
                    ResultSet rset1 = stmt.executeQuery(strSelect1);
                    if (rset1.next()) {

                        int Quantity = rset1.getInt("Quantity");
                        Quantity = Quantity - 1;
                        String sqlInsert1 = "update Books set Quantity=" + Quantity + " where BookID=" + t5.getText();
                        stmt.executeUpdate(sqlInsert1);
                    }

                    t1.setText("");
                    t2.setText("");
                    t3.setText("");
                    t4.setText("");
                    t5.setText("");
                    t6.setText("");
                    t7.setText("");
                    l1.clearSelection();
                    bg.clearSelection();


                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
                Home.main(new String[] {});
                dispose();
            }
        });

        // Search Book
        b2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/library", "root", "12345678");
                    Statement stmt = conn.createStatement();
                    String strSelect = "select *  from Books where BookID=" + t5.getText();
                    ResultSet rset = stmt.executeQuery(strSelect);
                    if (rset.next()) {

                        String Bookname = rset.getString("BookName");
                        String Authorname = rset.getString("AuthorName");
                        int Quantity = rset.getInt("Quantity");
                        if (Quantity > 0) {
                            t6.setText(Bookname);
                            t7.setText(Authorname);

                        } else {
                            JOptionPane.showMessageDialog(AddRecord.this, "Book is not available");

                        }
                    } else {
                        JOptionPane.showMessageDialog(AddRecord.this, "Book is not available");
                        t6.setText("");
                        t7.setText("");
                    }

                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }

        });

        // Go to Home Frame
        b3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Home.main(new String[]{});
                AddRecord.this.dispose();

            }
        });

        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:2710/library", "root", "akshu");
            Statement stmt = conn.createStatement();
            String strSelect = "select *  from Records order by RecordNo desc";
            ResultSet rset = stmt.executeQuery(strSelect);
            if (rset.next()) {
                String RecordNo = rset.getString("RecordNo");
                int Record_No = Integer.parseInt(RecordNo) + 1;

                t1.setText(Integer.toString(Record_No));
            }


        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {

        new AddRecord();
    }

}
