package LibraryManagementSystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

import BackImage.FullScreenBackground;

public class RemoveRecord extends JFrame {

    public RemoveRecord() {
        // Create a FullScreenBackground panel with the desired image
        FullScreenBackground backgroundPanel = new FullScreenBackground("C:/Users/ptmoh/Desktop/Akshata_2009/Library images/book.jpg");

        // Set layout for the backgroundPanel
        backgroundPanel.setLayout(null);

        JLabel j, j1, j2, j3, j6, j7, j8, j9;
        JTextField t1, t2, t3, t4, t5, t6, t7;
        JButton b1, b2, b3;

        j = new JLabel("Remove Record ");
        j1 = new JLabel("Record No :");
        j2 = new JLabel("Enrollment No :");
        j3 = new JLabel("Student Name ");
        j6 = new JLabel("Mobile No :");
        j7 = new JLabel("Book ID :");
        j8 = new JLabel("Book Name :");
        j9 = new JLabel("Author Name");

        t1 = new JTextField();
        t2 = new JTextField();
        t3 = new JTextField();
        t4 = new JTextField();

        t5 = new JTextField();
        t6 = new JTextField();
        t7 = new JTextField();

        b1 = new JButton("Remove Record");
        b2 = new JButton("Search");
        b3 = new JButton("Back");

        j.setBounds(800, 150, 400, 40);
        j1.setBounds(200, 250, 150, 30);
        j2.setBounds(200, 400, 180, 30);
        j3.setBounds(200, 450, 150, 30);
        j6.setBounds(1050, 250, 150, 30);
        j7.setBounds(1050, 350, 150, 30);
        j8.setBounds(1050, 400, 150, 30);
        j9.setBounds(1050, 450, 150, 30);

        t1.setBounds(400, 250, 250, 30);
        t2.setBounds(400, 400, 250, 30);
        t3.setBounds(400, 450, 250, 30);

        t4.setBounds(1250, 250, 250, 30);
        t5.setBounds(1250, 350, 250, 30);
        t6.setBounds(1250, 400, 250, 30);
        t7.setBounds(1250, 450, 250, 30);

        b1.setBounds(850, 700, 200, 30);
        b2.setBounds(1150, 320, 120, 30);
        b3.setBounds(750, 100, 180, 30);

        backgroundPanel.add(j);
        backgroundPanel.add(j1);
        backgroundPanel.add(j2);
        backgroundPanel.add(j3);
        backgroundPanel.add(j6);
        backgroundPanel.add(j7);
        backgroundPanel.add(j8);
        backgroundPanel.add(j9);
        backgroundPanel.add(t1);
        backgroundPanel.add(t2);
        backgroundPanel.add(t3);
        backgroundPanel.add(t4);
        backgroundPanel.add(t5);
        backgroundPanel.add(t6);
        backgroundPanel.add(t7);
        backgroundPanel.add(b1);
        backgroundPanel.add(b2);
        backgroundPanel.add(b3);

        setTitle("Remove Record");
        setSize(1100, 900);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(backgroundPanel);
        setVisible(true);
        setExtendedState(JFrame.MAXIMIZED_BOTH);

        Font myfont = new Font("serif", Font.BOLD, 24);
        j1.setFont(myfont);
        j2.setFont(myfont);
        j3.setFont(myfont);
        j6.setFont(myfont);
        j7.setFont(myfont);
        j8.setFont(myfont);
        j9.setFont(myfont);
        b1.setFont(myfont);
        b2.setFont(myfont);
        b3.setFont(myfont);
        t1.setFont(myfont);
        t2.setFont(myfont);
        t3.setFont(myfont);
        t4.setFont(myfont);
        t5.setFont(myfont);
        t6.setFont(myfont);
        t7.setFont(myfont);

        Font Title = new Font("serif", Font.BOLD, 40);
        j.setForeground(Color.RED);
        j.setFont(Title);

        // Search Record
        b2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (t1.getText().equals("")) {
                    JOptionPane.showMessageDialog(RemoveRecord.this, "Please enter Record No");
                } else {
                    try {
                        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:2710/library", "root", "akshu");
                        Statement stmt = conn.createStatement();
                        String strSelect = "select *  from Records where RecordNo=" + t1.getText();
                        ResultSet rset = stmt.executeQuery(strSelect);
                        if (rset.next()) {
                            int RecordNo = rset.getInt("RecordNo");
                            int EnrollmentNo = rset.getInt("EnrollmentNo");
                            String StudentName = rset.getString("StudentName");
                            long MobileNo = rset.getLong("MobileNo");
                            int BookID = rset.getInt("BookID");
                            String BookName = rset.getString("BookName");
                            String AuthorName = rset.getString("AuthorName");
                            t2.setText("" + EnrollmentNo + "");
                            t3.setText(StudentName);
                            t4.setText("" + MobileNo + "");
                            t5.setText("" + BookID + "");
                            t6.setText(BookName);
                            t7.setText(AuthorName);
                        } else {
                            JOptionPane.showMessageDialog(RemoveRecord.this, "No Record Found");
                        }
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });

        // Remove Record
        b1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:2710/library", "root", "akshu");
                    Statement stmt = conn.createStatement();
                    String sqlInsert = "delete from records where RecordNo=" + t1.getText();
                    stmt.executeUpdate(sqlInsert);
                    JOptionPane.showMessageDialog(RemoveRecord.this, "Record removed from the library successfully");

                    String strSelect1 = "select *  from Books where BookID=" + t5.getText();
                    ResultSet rset1 = stmt.executeQuery(strSelect1);
                    if (rset1.next()) {
                        int Quantity = rset1.getInt("Quantity");
                        Quantity = Quantity + 1;
                        String sqlInsert1 = "update Books set Quantity=" + Quantity + " where BookID=" + t5.getText();
                        stmt.executeUpdate(sqlInsert1);
                    }

                    t1.setText("");
                    t2.setText("");
                    t3.setText("");
                    t4.setText("");
                    t5.setText("");
                    t6.setText("");
                    t7.setText("");

                } catch (SQLException ex) {
                    ex.printStackTrace();
                }

            }
        });

        // Go to Home Frame
        b3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Home.main(new String[]{});
                RemoveRecord.this.dispose();
            }
        });
    }

    public static void main(String[] args) {
        new RemoveRecord();
    }
}