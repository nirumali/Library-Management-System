package LibraryManagementSystem;
import LibraryManagementSystem.Home;
import BackImage.FullScreenBackground;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;

public class Login extends JFrame {
    public static void main(String[] args) {
        new Login();
    }

    public Login() {
        // Create a FullScreenBackground panel with the desired image
        FullScreenBackground backgroundPanel = new FullScreenBackground("C:/Users/Niranjan Mali/Downloads/Library/Library/src/LibraryManagementSystem/lib1.jpg");

        // Set layout for the backgroundPanel
        backgroundPanel.setLayout(null);

        JLabel l1, l2, l3, l4;
        JTextField t1;
        JPasswordField p1;
        JButton b1;

        l1 = new JLabel("Username : ");
        l2 = new JLabel("Password: ");
        l3 = new JLabel("Library Management System");
        l4 = new JLabel("Librarian Login");

        t1 = new JTextField();
        p1 = new JPasswordField();
        b1 = new JButton("Submit");

        l1.setBounds(250, 320, 150, 40);
        t1.setBounds(400, 320, 200, 40);

        l2.setBounds(250, 390, 150, 40);
        p1.setBounds(400, 390, 200, 40);

        l3.setBounds(200, 100, 500, 50);
        l4.setBounds(350, 220, 300, 40);

        b1.setBounds(350, 500, 140, 40);

        p1.setEchoChar('*');

        backgroundPanel.add(l1);
        backgroundPanel.add(l2);
        backgroundPanel.add(l3);
        backgroundPanel.add(l4);
        backgroundPanel.add(t1);
        backgroundPanel.add(p1);
        backgroundPanel.add(b1);

        setContentPane(backgroundPanel);

        setTitle("Login");
        setSize(Toolkit.getDefaultToolkit().getScreenSize());
        setLayout(null);
        setVisible(true);

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                dispose();
            }
        });

        Font myfont = new Font("serif", Font.BOLD, 30);
        Font Title = new Font("serif", Font.BOLD, 40);

        l1.setFont(myfont);
        l2.setFont(myfont);

        l1.setForeground(Color.WHITE);
        l2.setForeground(Color.WHITE);
        l4.setForeground(Color.WHITE);
        l3.setForeground(Color.WHITE);
        l3.setFont(Title);
        l4.setFont(Title);

        t1.setFont(myfont);
        p1.setFont(myfont);

        b1.setFont(myfont);

        b1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Class.forName("com.mysql.jdbc.Driver");
                } catch (ClassNotFoundException ae) {
                    System.out.println("MySQL JDBC Driver not found.");
                    ae.printStackTrace();
                    return;
                }

                try {
                    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:2710/library", "root",
                            "akshu");
                    Statement stmt = conn.createStatement();
                    String strSelect = "select * from login where Username='" + t1.getText() + "'&& Password='"
                            + new String(p1.getPassword()) + "'";
                    ResultSet rset = stmt.executeQuery(strSelect);

                    if (rset.next()) {

                        JOptionPane.showMessageDialog(Login.this, "Login Successfully...!");
                        Home.main(new String[] {});
                        dispose();
                    } else {

                        JOptionPane.showMessageDialog(Login.this, "Invalid Login");
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }

            }
        });
    }
}
