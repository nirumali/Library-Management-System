package LibraryManagementSystem;

import BackImage.FullScreenBackground;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Home extends JFrame {
    public static void main(String[] args) 
    {
        new Home();
    }

    public Home() 
    {
        setTitle("Welcome Frame");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setSize(Toolkit.getDefaultToolkit().getScreenSize());
        setSize(900, 900);

        // Create a FullScreenBackground panel with the desired image
        FullScreenBackground backgroundPanel = new FullScreenBackground("C:/Users/ptmoh/Desktop/Akshata_2009/Library images/lib1.jpg");

        // Add your existing components to the backgroundPanel
        JButton b1 = new JButton("Add Book");
        JButton b2 = new JButton("Remove Book");
        JButton b3 = new JButton("Update Book");
        JButton b4 = new JButton("View Books");
        JButton b5 = new JButton("Add Record");
        JButton b6 = new JButton("Remove Record");
        JButton b7 = new JButton("All Records");
        JButton b8 = new JButton("Log Out");
        JLabel l1 = new JLabel("WELCOME LIBRARIAN");

        // Set layout for the backgroundPanel
        backgroundPanel.setLayout(null);

        // Set bounds for your components
        b1.setBounds(300, 300, 300, 40);
        b2.setBounds(300, 370, 300, 40);
        b3.setBounds(300, 440, 300, 40);
        b4.setBounds(300, 510, 300, 40);
        b5.setBounds(300, 580, 300, 40);
        b6.setBounds(300, 650, 300, 40);
        b7.setBounds(300, 720, 300, 40);
        b8.setBounds(650, 80, 150, 40);
        l1.setBounds(250, 200, 500, 40);

        // Add components to the backgroundPanel
        backgroundPanel.add(b1);
        backgroundPanel.add(b2);
        backgroundPanel.add(b3);
        backgroundPanel.add(b4);
        backgroundPanel.add(b5);
        backgroundPanel.add(b6);
        backgroundPanel.add(b7);
        backgroundPanel.add(b8);
        backgroundPanel.add(l1);

        // Add the backgroundPanel to the frame
        add(backgroundPanel);

        setVisible(true);
        Font myfont=new Font("serif",Font.BOLD,28);
		Font Title=new Font("serif",Font.BOLD,40);
		
		b1.setFont(myfont);
		b2.setFont(myfont);
		b3.setFont(myfont);
		b4.setFont(myfont);
		b5.setFont(myfont);
		b6.setFont(myfont);
		b7.setFont(myfont);
		b8.setFont(myfont);
		l1.setFont(Title);
		l1.setForeground(Color.RED);
		
        
        
        b1.addActionListener(new ActionListener() 
        {  
	            public void actionPerformed(ActionEvent e) 
	            { 
	            	 AddBook.main(new String[]{});
				     Home.this.dispose();
	            	
	            }
        });
	  
	  b2.addActionListener(new ActionListener() 
        {  
	            public void actionPerformed(ActionEvent e) 
	            { 
	            	 DeleteBook.main(new String[]{});
				     Home.this.dispose();
	            	
	            }
        });
	  b3.addActionListener(new ActionListener() 
        {  
	            public void actionPerformed(ActionEvent e) 
	            { 
	            	 UpdateBook.main(new String[]{});
				     Home.this.dispose();
	            	
	            }
        });
	  b4.addActionListener(new ActionListener() 
        {  
	            public void actionPerformed(ActionEvent e) 
	            { 
	            	 ViewBooks.main(new String[]{});
				     Home.this.dispose();
	            	
	            }
        });
	  b5.addActionListener(new ActionListener() 
        {  
	            public void actionPerformed(ActionEvent e) 
	            { 
	            	 AddRecord.main(new String[]{});
				     Home.this.dispose();
	            	
	            }
        });
	  b6.addActionListener(new ActionListener() 
        {  
	            public void actionPerformed(ActionEvent e) 
	            { 
	            	 RemoveRecord.main(new String[]{});
				     Home.this.dispose();
	            	
	            }
        });
	  b7.addActionListener(new ActionListener() 
        {  
	            public void actionPerformed(ActionEvent e) 
	            { 
	            	 ViewRecords.main(new String[]{});
				     Home.this.dispose();
	            	
	            }
        });
	  
	  b8.addActionListener(new ActionListener() 
        {  
	            public void actionPerformed(ActionEvent e) 
	            { 
	            	 Login.main(new String[]{});
				     Home.this.dispose();
	            	
	            }
        });
	  
		addWindowListener(new WindowAdapter()
		{  
           public void windowClosing(WindowEvent e)
           {  
               dispose();  
           }  
       });
}


}