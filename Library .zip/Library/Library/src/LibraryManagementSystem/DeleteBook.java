package LibraryManagementSystem;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.*;

import BackImage.FullScreenBackground;


public class DeleteBook extends JFrame {
	public static void main(String[] args) 
	{
		
		new DeleteBook();
	}

	JLabel l1,l2,l3,l4,l5;
	JTextField t1,t2,t3,t4;
	JButton b1,b2,b3;
	
	public DeleteBook()
	{
		// Create a FullScreenBackground panel with the desired image
        FullScreenBackground backgroundPanel = new FullScreenBackground("C:/Users/ptmoh/Desktop/Akshata_2009/Library images/lib2.jpg");

        // Set layout for the backgroundPanel
        backgroundPanel.setLayout(null);
		l1=new JLabel("Book ID");
		t1=new JTextField();
		l2=new JLabel("Book Name");
		t2=new JTextField();
		l3=new JLabel("Author name");
		t3=new JTextField();
		l4=new JLabel("Copies");
		t4=new JTextField();
		l5=new JLabel("DELETE BOOK");
		b1=new JButton("Delete Book");
		b2=new JButton("Search Book");
		b3=new JButton("Back");
		
		
		l1.setBounds(120, 300, 200, 40);
		t1.setBounds(350, 300, 250, 40);
		l2.setBounds(120, 380, 200, 40);
		t2.setBounds(350, 380, 250, 40);
		l3.setBounds(120, 460, 200, 40);
		t3.setBounds(350, 460, 250, 40);
		l4.setBounds(120, 540, 200, 40);
		t4.setBounds(350, 540, 250, 40);
		b1.setBounds(250, 700, 200, 40);
		b2.setBounds(640, 300, 200, 40);
		b3.setBounds(650, 80, 200, 40);
		l5.setBounds(250, 200, 400, 40);
		
		backgroundPanel.add(l1);
		backgroundPanel.add(t1);
		backgroundPanel.add(l2);
		backgroundPanel.add(t2);
		backgroundPanel.add(l3);
		backgroundPanel.add(t3);
		backgroundPanel.add(l4);
		backgroundPanel.add(t4);
		backgroundPanel.add(l5);
		backgroundPanel.add(b1);
		backgroundPanel.add(b2);
		backgroundPanel.add(b3);
		
		// Set content pane to the background panel
        setContentPane(backgroundPanel);
        
		//getContentPane().setBackground(Color.YELLOW);
		setTitle("Delete Book");
		setSize(900,900);
		setLayout(null);
		setVisible(true);
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		
		Font myfont=new Font("serif",Font.BOLD,28);
		l1.setFont(myfont);
		l2.setFont(myfont);
		l3.setFont(myfont);
		l4.setFont(myfont);
		t1.setFont(myfont);
		t2.setFont(myfont);
		t3.setFont(myfont);
		t4.setFont(myfont);
		b1.setFont(myfont);
		b2.setFont(myfont);
		b3.setFont(myfont);

		
		Font Title=new Font("serif",Font.BOLD,40);
		l1.setForeground(Color.WHITE);
		l2.setForeground(Color.WHITE);
		l3.setForeground(Color.WHITE);
		l4.setForeground(Color.WHITE);
		l5.setForeground(Color.RED);
		l5.setFont(Title);
		
		//Delete book
		 b1.addActionListener(new ActionListener() {  
	            public void actionPerformed(ActionEvent e) {       
					try{Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:2710/library","root","akshu"); 
			          Statement stmt = conn.createStatement();
				         String sqlInsert = "delete from books where BookID='"+t1.getText()+"'";  
				         stmt.executeUpdate(sqlInsert);
				         JOptionPane.showMessageDialog(DeleteBook.this,"" +t2.getText()+ " " +t4.getText()+ " copies removed from the library. \n");
				            t2.setText("");
				 			t3.setText("");
				 			t4.setText("");
				}
					catch(SQLException ex) {
						ex.printStackTrace();
						}
			}  
			}); 
		 
		 //Search book
		  b2.addActionListener(new ActionListener() 
	         {  
		            public void actionPerformed(ActionEvent e) 
		            { 
		            	
		            	if(t1.getText().equals(""))
		            	{
		            		 JOptionPane.showMessageDialog(DeleteBook.this,"Please enter BookID");
		            		
		            	}
		            	else{
		            	try{
		            	 Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:2710/library","root","akshu");
		    	         Statement stmt = conn.createStatement();
		    	         String strSelect = "select *  from Books where BookID="+t1.getText()+" ";
		    	         ResultSet rset = stmt.executeQuery(strSelect);
		    	         if(rset.next())
		    	         {
		 				String Bookname = rset.getString("BookName");
		 	            String Authorname = rset.getString("AuthorName");
		 	            int Quantity = rset.getInt("Quantity");
		 				t2.setText(Bookname);
		 				t3.setText(Authorname);
		 				t4.setText(""+Quantity);
		    	         }
		    	         else
		    	         {
		    	        	 JOptionPane.showMessageDialog(DeleteBook.this,"No Book Found");
		    	        	 t2.setText("");
				 			t3.setText("");
				 			t4.setText("");
		    	         }
		            	}
		            	catch(SQLException ex) {
							ex.printStackTrace();
							}
		            	}
		            }
	         });
	         
		  
		 
		  b3.addActionListener(new ActionListener() 
	         {  
		            public void actionPerformed(ActionEvent e) 
		            { 
		            	 Home.main(new String[]{});
					     DeleteBook.this.dispose();
		            	
		            }
	         });
		  
		  
		
		addWindowListener(new WindowAdapter()
		{  
            public void windowClosing(WindowEvent e)
            {  
                dispose();  
            }  
        });
	}

	

}
